<?php return array('dependencies' => array(), 'version' => 'fdca1d783fdb0e45c270');
