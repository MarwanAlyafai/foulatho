<?php return array('dependencies' => array(), 'version' => '2799c1f98adeb1aea672');
