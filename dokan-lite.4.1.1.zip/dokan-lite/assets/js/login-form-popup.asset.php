<?php return array('dependencies' => array(), 'version' => '7a72fe8fbfd894b698a2');
