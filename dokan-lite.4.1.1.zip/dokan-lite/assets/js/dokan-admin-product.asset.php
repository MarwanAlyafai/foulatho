<?php return array('dependencies' => array(), 'version' => '19bc8d5d29f3f3a636e2');
