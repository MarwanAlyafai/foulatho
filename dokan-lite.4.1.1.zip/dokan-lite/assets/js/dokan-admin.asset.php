<?php return array('dependencies' => array(), 'version' => 'ba6fdda32619e907a1e7');
