<?php return array('dependencies' => array(), 'version' => '60055a7b2c2c8cb49dac');
