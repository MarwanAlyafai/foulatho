<?php return array('dependencies' => array('jquery', 'wp-i18n'), 'version' => 'b1191539c24018987af3');
