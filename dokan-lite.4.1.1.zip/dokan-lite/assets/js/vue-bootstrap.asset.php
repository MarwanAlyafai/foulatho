<?php return array('dependencies' => array('jquery', 'moment', 'wp-api-fetch', 'wp-i18n', 'wp-url'), 'version' => 'f490f0e54b6b714baab1');
