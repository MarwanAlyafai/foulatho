<?php return array('dependencies' => array(), 'version' => '9e87fcd85934bf17050c');
