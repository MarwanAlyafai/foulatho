<?php return array('dependencies' => array('dokan-stores-product-categories', 'dokan-stores-products', 'wp-api-fetch', 'wp-data', 'wp-element', 'wp-url'), 'version' => 'b2348acd742f60ff0811');
