<?php return array('dependencies' => array(), 'version' => '9ed669f483f1ef1cf0dc');
