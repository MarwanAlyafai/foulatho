<?php return array('dependencies' => array(), 'version' => '1f7b3b398b49befa6c08');
