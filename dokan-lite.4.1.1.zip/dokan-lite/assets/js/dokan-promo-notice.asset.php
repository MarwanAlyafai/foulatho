<?php return array('dependencies' => array('jquery', 'wp-i18n'), 'version' => '866dc99816137757845d');
