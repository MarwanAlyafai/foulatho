<?php return array('dependencies' => array(), 'version' => '2e6a5570d9de4c39fb86');
