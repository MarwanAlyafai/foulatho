<?php return array('dependencies' => array(), 'version' => 'efbe1ff313774ccc2627');
