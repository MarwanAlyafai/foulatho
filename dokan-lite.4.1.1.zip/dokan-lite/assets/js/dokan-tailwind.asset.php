<?php return array('dependencies' => array(), 'version' => '09e69e218fd86ae55942');
