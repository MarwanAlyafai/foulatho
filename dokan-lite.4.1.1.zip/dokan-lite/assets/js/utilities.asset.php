<?php return array('dependencies' => array('wc-date'), 'version' => '876169a6b62692462a43');
