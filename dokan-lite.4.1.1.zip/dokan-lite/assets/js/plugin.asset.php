<?php return array('dependencies' => array(), 'version' => 'bada8558a1178eb8b335');
