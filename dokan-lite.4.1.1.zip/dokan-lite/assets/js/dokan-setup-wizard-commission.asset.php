<?php return array('dependencies' => array(), 'version' => '664d63464cf0f1780070');
