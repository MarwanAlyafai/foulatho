<div class="dokan-form-group">
    <?php if ( $show_label ): ?>
        <label for="product_brands" class="form-label"><?php esc_html_e( 'Brand', 'dokan' ); ?></label>
    <?php endif; ?>

    <?php echo $brand_dropdown; ?>
</div>
